setwd("C://Users//user//Desktop//IT24200536")
getwd()

branch_data <- read.table("Exercise.txt", header=TRUE)  # Assume header if present

boxplot(branch_data$sales, main="Boxplot of Sales")

boxplot(branch_data$sales, main="Boxplot of Sales")

summary(branch_data$advertising)  # Min, Q1, Median, Mean, Q3, Max
IQR(branch_data$advertising)

outliers(branch_data$years)
setwd("C://Users//user//Desktop//IT24200536")
getwd()

setwd("D:/2025 - Sem 2/IT2120/Lab Sessions/Lab 04")
X1 <- c(31102, 44497, 41498, 45488, 29299, 32788, 17609, 22144, 42806, 46806, 17840, 22157, 30631, 18922, 38139, 22931, 14395, 11295, 29714, 36872, 15600, 21718, 19512, 32354, 24070, 32735, 39946, 29948, 36141, 30300)
X2 <- c(38537000, 29161500, 59536000, 70408134, 51647000, 49383000, 36840000, 21995000, 59033499, 47433333, 22625000, 33434000, 40629000, 32912500, 47970000, 32252583, 26182500, 9202000, 49559665, 63159898, 20063000, 36085000, 13752000, 45368000, 40320835, 52032291, 52572500, 25317500, 54704595, 48415000)
X3 <- c(32, 0, 1, 6, 86, 82, 7, 28, 4, 3, 86, 5, 33, 25, 36, 45, 16, 22, 34, 75, 30, 27, 28, 29, 38, 21, 32, 0, 4, 9)

#2.b
# For X1 (repeat similarly for X2, X3)
boxplot(X1, main="Boxplot of Team Attendance", ylab="Attendance")
hist(X1, main="Histogram of Team Attendance", xlab="Attendance")
stem(X1)
# For X2
boxplot(X2, main="Boxplot of Team Salary", ylab="Salary")
hist(X2, main="Histogram of Team Salary", xlab="Salary")
stem(X2)
# For X3
boxplot(X3, main="Boxplot of Years", ylab="Years")
hist(X3, main="Histogram of Years", xlab="Years")
stem(X3)

mean(X1); median(X1); sd(X1)
# Repeat for X2, X3

quantile(X1, c(0.25, 0.75))
# Repeat for X2, X3

IQR(X1)
# Repeat for X2, X3

modes <- function(x) {
  tab <- table(x)
  max_freq <- max(tab)
  as.numeric(names(tab[tab == max_freq]))
}
modes(X3)

outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- IQR(x)
  lower <- q1 - 1.5 * iqr
  upper <- q3 + 1.5 * iqr
  x[x < lower | x > upper]
}
# Check
outliers(X1)  # None
outliers(X2)  # None
outliers(X3)  # 82, 86

branch_data <- read.table("Exercise.txt", header=TRUE)
branch_data <- read.table("Exercise.txt", header=TRUE)  # Assume header if present

setwd("C://Users//user//Desktop//IT24200536")
getwd()

branch_data <- read.table("C://Users//user//Desktop//IT24200536", header=TRUE)

setwd("C://Users//user//Desktop//IT24200536")
getwd()
branch_data <- read.table("exercise.txt", header=TRUE)

branch_data <- read.table("C:/Users/user/Downloads/Exercise.txt", header=TRUE)

str(branch_data)
cat("Sales: Quantitative, Ratio scale\n")
cat("Advertising: Quantitative, Ratio scale\n")
cat("Years: Quantitative, Ratio scale\n")


summary(branch_data$advertising) 
IQR(branch_data$advertising)


outliers <- function(x) {
  q1 <- quantile(x, 0.25)
  q3 <- quantile(x, 0.75)
  iqr <- IQR(x)
  lower <- q1 - 1.5 * iqr
  upper <- q3 + 1.5 * iqr
  x[x < lower | x > upper]
}
outliers(branch_data$years)
